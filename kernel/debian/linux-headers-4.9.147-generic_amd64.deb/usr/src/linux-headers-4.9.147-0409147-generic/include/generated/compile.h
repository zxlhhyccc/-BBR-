/* This file is auto generated, version 201812211431 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201812211431 SMP Fri Dec 21 14:33:45 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu 7.3.0-16ubuntu3) "
