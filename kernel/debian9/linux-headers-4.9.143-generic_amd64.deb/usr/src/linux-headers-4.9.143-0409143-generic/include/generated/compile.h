/* This file is auto generated, version 201812051441 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201812051441 SMP Wed Dec 5 19:45:22 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu 7.3.0-16ubuntu3) "
