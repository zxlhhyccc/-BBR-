/* This file is auto generated, version 201812170433 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201812170433 SMP Mon Dec 17 09:35:34 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 8.2.0 (Ubuntu 8.2.0-12ubuntu1)"
