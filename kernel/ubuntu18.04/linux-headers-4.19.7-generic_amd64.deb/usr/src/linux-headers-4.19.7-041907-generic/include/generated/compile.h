/* This file is auto generated, version 201812052010 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201812052010 SMP Wed Dec 5 20:11:58 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc version 8.2.0 (Ubuntu 8.2.0-10ubuntu1)"
